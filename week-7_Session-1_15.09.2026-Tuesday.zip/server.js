const express = require("express");
const jwt = require("jsonwebtoken");

const app = express();

app.use(express.json());

const PORT = 3000;

const SECRET_KEY = "mysecretkey";

let users = [];

let students = [
    {
        id: 1,
        name: "Ravi",
        age: 20,
        course: "CSE"
    },
    {
        id: 2,
        name: "Sita",
        age: 21,
        course: "CSE"
    }
];

// Home API
app.get("/", (req, res) => {
    res.json({
        message: "Welcome to Secure Student API"
    });
});

// Register API
app.post("/register", (req, res) => {

    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({
            message: "Username and password are required"
        });
    }

    const existingUser = users.find(
        user => user.username === username
    );

    if (existingUser) {
        return res.status(400).json({
            message: "User already exists"
        });
    }

    const newUser = {
        id: users.length + 1,
        username: username,
        password: password
    };

    users.push(newUser);

    res.status(201).json({
        message: "User registered successfully"
    });
});

// Login API
app.post("/login", (req, res) => {

    const { username, password } = req.body;

    const user = users.find(
        user =>
            user.username === username &&
            user.password === password
    );

    if (!user) {
        return res.status(401).json({
            message: "Invalid username or password"
        });
    }

    const token = jwt.sign(
        {
            userId: user.id,
            username: user.username
        },
        SECRET_KEY,
        {
            expiresIn: "1h"
        }
    );

    res.json({
        message: "Login successful",
        token: token
    });
});

// JWT Authentication Middleware
function authenticateToken(req, res, next) {

    const authHeader = req.headers["authorization"];

    const token = authHeader && authHeader.split(" ")[1];

    if (!token) {
        return res.status(401).json({
            message: "Access denied. Token missing."
        });
    }

    jwt.verify(token, SECRET_KEY, (err, user) => {

        if (err) {
            return res.status(401).json({
                message: "Invalid or expired token"
            });
        }

        req.user = user;

        next();
    });
}

// GET all students
app.get("/students", authenticateToken, (req, res) => {

    res.json(students);

});

// POST add a student
app.post("/students", authenticateToken, (req, res) => {

    const { name, age, course } = req.body;

    if (!name || !age || !course) {
        return res.status(400).json({
            message: "name, age and course are required"
        });
    }

    const newStudent = {
        id: students.length + 1,
        name: name,
        age: age,
        course: course
    };

    students.push(newStudent);

    res.status(201).json(newStudent);

});

// GET student by ID
app.get("/students/:id", authenticateToken, (req, res) => {

    const student = students.find(
        student => student.id === Number(req.params.id)
    );

    if (!student) {
        return res.status(404).json({
            message: "Student not found"
        });
    }

    res.json(student);

});

// 404 Middleware
app.use((req, res) => {

    res.status(404).json({
        message: "Route not found"
    });

});

// Start Server
app.listen(PORT, () => {

    console.log(`Server running on http://localhost:${PORT}`);

});