function StudentProfile({ name, studentId, department }) {
  return (
    <section id="profile" className="section">
      <h2>Student Profile</h2>

      <div className="profile-card">
        <p>
          <strong>Name:</strong> {name}
        </p>

        <p>
          <strong>Student ID:</strong> {studentId}
        </p>

        <p>
          <strong>Department:</strong> {department}
        </p>
      </div>
    </section>
  );
}

export default StudentProfile;