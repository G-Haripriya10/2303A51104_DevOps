function Header() {
  return (
    <header className="header">
      <h1>Student Course Registration System</h1>

      <nav>
        <a href="#profile">Student Profile</a>
        <a href="#courses">Available Courses</a>
        <a href="#registration">Registered Courses</a>
      </nav>
    </header>
  );
}

export default Header;