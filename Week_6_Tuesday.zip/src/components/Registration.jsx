function Registration({ registeredCourses, onRemove }) {
  return (
    <section id="registration" className="section">
      <h2>Registered Courses</h2>

      {registeredCourses.length === 0 ? (
        <p>No courses registered yet.</p>
      ) : (
        <div className="registered-list">
          {registeredCourses.map((course) => (
            <div className="registered-course" key={course.id}>
              <h3>{course.name}</h3>

              <p>
                <strong>Code:</strong> {course.code}
              </p>

              <button onClick={() => onRemove(course.id)}>
                Remove
              </button>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

export default Registration;