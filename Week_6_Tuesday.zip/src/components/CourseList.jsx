import Course from "./Course";

function CourseList({ courses, onRegister }) {
  return (
    <section id="courses" className="section">
      <h2>Available Courses</h2>

      <div className="course-list">
        {courses.map((course) => (
          <Course
            key={course.id}
            course={course}
            onRegister={onRegister}
          />
        ))}
      </div>
    </section>
  );
}

export default CourseList;