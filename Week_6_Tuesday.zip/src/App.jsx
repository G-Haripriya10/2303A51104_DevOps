import { useState } from "react";
import Header from "./components/Header";
import StudentProfile from "./components/StudentProfile";
import CourseList from "./components/CourseList";
import Registration from "./components/Registration";
import Footer from "./components/Footer";
import "./App.css";

function App() {
  const [registeredCourses, setRegisteredCourses] = useState([]);

  const courses = [
    {
      id: 1,
      name: "Data Structures",
      code: "CS301",
      department: "CSE",
      credits: 4,
    },
    {
      id: 2,
      name: "Database Management Systems",
      code: "CS302",
      department: "CSE",
      credits: 4,
    },
    {
      id: 3,
      name: "Operating Systems",
      code: "CS303",
      department: "CSE",
      credits: 3,
    },
    {
      id: 4,
      name: "Computer Networks",
      code: "CS304",
      department: "CSE",
      credits: 3,
    },
  ];

  const registerCourse = (course) => {
    if (!registeredCourses.some((item) => item.id === course.id)) {
      setRegisteredCourses([...registeredCourses, course]);
    }
  };

  const removeCourse = (id) => {
    setRegisteredCourses(
      registeredCourses.filter((course) => course.id !== id)
    );
  };

  return (
    <div>
      <Header />

      <StudentProfile
        name="Sarayu"
        studentId="SRU2027CSE001"
        department="Computer Science and Engineering"
      />

      <CourseList
        courses={courses}
        onRegister={registerCourse}
      />

      <Registration
        registeredCourses={registeredCourses}
        onRemove={removeCourse}
      />

      <Footer />
    </div>
  );
}

export default App;